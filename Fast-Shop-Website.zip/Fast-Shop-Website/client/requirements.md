## Packages
framer-motion | Essential for high-quality, premium page transitions and micro-interactions

## Notes
Tailwind Config - Please add the following to tailwind.config.ts theme.extend:
fontFamily: {
  sans: ["var(--font-sans)", "sans-serif"],
  display: ["var(--font-display)", "sans-serif"],
}
