import { useState } from "react";
import { useLocation } from "wouter";
import { Search, FilterX } from "lucide-react";
import { useProducts } from "@/hooks/use-products";
import { useCategories } from "@/hooks/use-categories";
import { ProductCard } from "@/components/product/ProductCard";
import { Spinner } from "@/components/ui/spinner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Products() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [categoryId, setCategoryId] = useState<string | undefined>(searchParams.get("categoryId") || undefined);
  
  // Using a local state to trigger fetch only on submit or clear
  const [activeSearch, setActiveSearch] = useState(search);

  const { data: categories, isLoading: catsLoading } = useCategories();
  const { data: products, isLoading: prodsLoading } = useProducts(categoryId, activeSearch);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveSearch(search);
  };

  const handleCategorySelect = (id?: string) => {
    setCategoryId(id);
    // Optional: update URL
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
        <div>
          <h1 className="text-4xl font-display font-extrabold text-foreground mb-4">Shop All</h1>
          <p className="text-muted-foreground text-lg max-w-2xl text-balance">
            Discover our full collection. From the latest tech gadgets to gripping novels, find exactly what you're looking for.
          </p>
        </div>
        
        <form onSubmit={handleSearch} className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Search products..." 
            className="w-full pl-12 pr-4 h-14 rounded-xl border-2 bg-secondary/50 focus:bg-background transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </form>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-64 shrink-0">
          <div className="bg-card border border-border p-6 rounded-2xl sticky top-28">
            <h3 className="font-display font-bold text-lg mb-6 flex items-center justify-between">
              Categories
              {(categoryId || activeSearch) && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 text-muted-foreground hover:text-destructive px-2"
                  onClick={() => {
                    setCategoryId(undefined);
                    setSearch("");
                    setActiveSearch("");
                  }}
                >
                  <FilterX className="w-4 h-4 mr-1" /> Clear
                </Button>
              )}
            </h3>
            
            {catsLoading ? (
              <Spinner className="w-6 h-6" />
            ) : (
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => handleCategorySelect(undefined)}
                  className={`text-left px-4 py-3 rounded-xl transition-all ${
                    !categoryId ? "bg-primary text-primary-foreground font-semibold shadow-md" : "hover:bg-secondary text-foreground"
                  }`}
                >
                  All Products
                </button>
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategorySelect(cat.id.toString())}
                    className={`text-left px-4 py-3 rounded-xl transition-all ${
                      categoryId === cat.id.toString() 
                        ? "bg-primary text-primary-foreground font-semibold shadow-md" 
                        : "hover:bg-secondary text-foreground"
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* Product Grid */}
        <main className="flex-1">
          {prodsLoading ? (
            <div className="flex justify-center py-20">
              <Spinner />
            </div>
          ) : products?.length === 0 ? (
            <div className="text-center py-32 bg-secondary/30 rounded-3xl border border-dashed border-border">
              <div className="w-20 h-20 bg-background rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                <Search className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-2xl font-display font-bold text-foreground mb-2">No products found</h3>
              <p className="text-muted-foreground">Try adjusting your filters or search terms.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6 md:gap-8">
              {products?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
