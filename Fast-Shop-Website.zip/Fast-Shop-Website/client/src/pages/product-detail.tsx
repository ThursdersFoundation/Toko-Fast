import { useRoute } from "wouter";
import { ShieldCheck, Truck, RotateCcw, ShoppingCart } from "lucide-react";
import { useProduct } from "@/hooks/use-products";
import { useAddToCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatPrice } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { useState } from "react";
import { motion } from "framer-motion";

export default function ProductDetail() {
  const [, params] = useRoute("/products/:id");
  const productId = Number(params?.id);
  
  const { data: product, isLoading } = useProduct(productId);
  const { mutate: addToCart, isPending } = useAddToCart();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [quantity, setQuantity] = useState(1);

  if (isLoading) {
    return <div className="min-h-[70vh] flex items-center justify-center"><Spinner /></div>;
  }

  if (!product) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center">
        <h2 className="text-4xl font-display font-bold mb-4">Product Not Found</h2>
        <p className="text-muted-foreground mb-8">The product you're looking for doesn't exist.</p>
        <Button asChild><a href="/products">Back to Shop</a></Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }

    addToCart({ productId: product.id, quantity }, {
      onSuccess: () => {
        toast({
          title: "Added to Cart",
          description: `${quantity}x ${product.name} added to your cart.`,
        });
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
        
        {/* Images */}
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-secondary/40 rounded-3xl p-8 border border-border flex items-center justify-center relative overflow-hidden"
        >
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full max-w-md object-contain mix-blend-multiply drop-shadow-2xl hover:scale-105 transition-transform duration-500"
          />
        </motion.div>

        {/* Details */}
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-col justify-center"
        >
          {product.category && (
            <span className="text-primary font-bold tracking-wider uppercase text-sm mb-4">
              {product.category.name}
            </span>
          )}
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-foreground mb-6 leading-tight text-balance">
            {product.name}
          </h1>
          
          <div className="text-3xl font-bold text-foreground mb-8">
            {formatPrice(product.price)}
          </div>
          
          <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
            {product.description}
          </p>

          <div className="bg-card border border-border rounded-2xl p-6 mb-10 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <span className="font-semibold text-foreground">Quantity</span>
              <div className="flex items-center gap-4 bg-secondary rounded-xl p-1">
                <button 
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-10 h-10 rounded-lg bg-background shadow-sm flex items-center justify-center font-bold hover:text-primary transition-colors disabled:opacity-50"
                  disabled={quantity <= 1}
                >
                  -
                </button>
                <span className="w-8 text-center font-bold">{quantity}</span>
                <button 
                  onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                  className="w-10 h-10 rounded-lg bg-background shadow-sm flex items-center justify-center font-bold hover:text-primary transition-colors disabled:opacity-50"
                  disabled={quantity >= product.stock}
                >
                  +
                </button>
              </div>
            </div>

            <Button 
              size="lg" 
              className="w-full h-14 text-lg rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-1 transition-all gap-3"
              onClick={handleAddToCart}
              disabled={isPending || product.stock === 0}
            >
              {isPending ? <Spinner className="w-5 h-5 text-white" /> : <ShoppingCart className="w-6 h-6" />}
              {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
            </Button>
            
            {product.stock > 0 && product.stock <= 5 && (
              <p className="text-center text-accent text-sm mt-4 font-medium">
                Hurry! Only {product.stock} items left in stock.
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-border">
            <div className="flex flex-col items-center text-center gap-2">
              <Truck className="w-6 h-6 text-primary" />
              <span className="text-sm font-semibold">Free Delivery</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <ShieldCheck className="w-6 h-6 text-primary" />
              <span className="text-sm font-semibold">1 Year Warranty</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <RotateCcw className="w-6 h-6 text-primary" />
              <span className="text-sm font-semibold">30-Day Returns</span>
            </div>
          </div>

        </motion.div>
      </div>
    </div>
  );
}
