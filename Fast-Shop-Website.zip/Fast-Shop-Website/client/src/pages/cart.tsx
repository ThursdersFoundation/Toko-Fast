import { Link } from "wouter";
import { Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart, useUpdateCartItem, useRemoveFromCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { formatPrice } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function Cart() {
  const { isAuthenticated } = useAuth();
  const { data: cartItems, isLoading } = useCart();
  const { mutate: updateQuantity } = useUpdateCartItem();
  const { mutate: removeItem, isPending: isRemoving } = useRemoveFromCart();
  const { toast } = useToast();

  if (!isAuthenticated) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <ShoppingBag className="w-12 h-12 text-primary" />
        </div>
        <h2 className="text-4xl font-display font-bold mb-4">Your Cart is Waiting</h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-md">Log in to view your cart and proceed to checkout.</p>
        <Button size="lg" className="rounded-xl h-14 px-8" onClick={() => window.location.href = "/api/login"}>
          Log In or Sign Up
        </Button>
      </div>
    );
  }

  if (isLoading) {
    return <div className="min-h-[70vh] flex items-center justify-center"><Spinner /></div>;
  }

  const subtotal = cartItems?.reduce((sum, item) => sum + (item.product.price * item.quantity), 0) || 0;
  const tax = Math.round(subtotal * 0.08); // 8% dummy tax
  const total = subtotal + tax;

  const handleCheckout = () => {
    toast({
      title: "Checkout Initiated",
      description: "This is a demo. Actual payment integration required.",
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
      <h1 className="text-4xl font-display font-extrabold text-foreground mb-12">Shopping Cart</h1>

      {cartItems?.length === 0 ? (
        <div className="text-center py-20 bg-secondary/30 rounded-3xl border border-dashed border-border">
          <ShoppingBag className="w-16 h-16 text-muted-foreground mx-auto mb-6 opacity-50" />
          <h3 className="text-2xl font-display font-bold text-foreground mb-4">Your cart is empty</h3>
          <p className="text-muted-foreground mb-8">Looks like you haven't added anything yet.</p>
          <Button asChild size="lg" className="rounded-xl"><Link href="/products">Start Shopping</Link></Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Cart Items List */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence>
              {cartItems?.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
                  className="flex flex-col sm:flex-row gap-6 p-6 bg-card border border-border shadow-sm rounded-2xl relative group"
                >
                  <Link href={`/products/${item.product.id}`} className="shrink-0">
                    <div className="w-full sm:w-32 aspect-square bg-secondary rounded-xl overflow-hidden p-2">
                      <img 
                        src={item.product.imageUrl} 
                        alt={item.product.name} 
                        className="w-full h-full object-contain mix-blend-multiply"
                      />
                    </div>
                  </Link>
                  
                  <div className="flex-1 flex flex-col justify-between">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <Link href={`/products/${item.product.id}`} className="block">
                          <h3 className="font-display font-bold text-xl leading-tight hover:text-primary transition-colors mb-2">
                            {item.product.name}
                          </h3>
                        </Link>
                        <p className="text-muted-foreground text-sm line-clamp-1 mb-4">
                          {item.product.description}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-lg block">
                          {formatPrice(item.product.price * item.quantity)}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {formatPrice(item.product.price)} each
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 bg-secondary rounded-xl p-1 w-fit">
                        <button 
                          onClick={() => updateQuantity({ id: item.id, quantity: Math.max(1, item.quantity - 1) })}
                          className="w-8 h-8 rounded-lg bg-background shadow-sm flex items-center justify-center font-bold hover:text-primary transition-colors disabled:opacity-50"
                          disabled={item.quantity <= 1}
                        >
                          -
                        </button>
                        <span className="w-8 text-center font-bold text-sm">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity({ id: item.id, quantity: Math.min(item.product.stock, item.quantity + 1) })}
                          className="w-8 h-8 rounded-lg bg-background shadow-sm flex items-center justify-center font-bold hover:text-primary transition-colors disabled:opacity-50"
                          disabled={item.quantity >= item.product.stock}
                        >
                          +
                        </button>
                      </div>

                      <button 
                        onClick={() => removeItem(item.id)}
                        disabled={isRemoving}
                        className="text-muted-foreground hover:text-destructive p-2 rounded-lg hover:bg-destructive/10 transition-colors flex items-center gap-2 text-sm font-semibold"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Remove</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card border border-border p-8 rounded-3xl sticky top-28 shadow-xl shadow-black/5">
              <h3 className="font-display font-bold text-2xl mb-6">Order Summary</h3>
              
              <div className="space-y-4 text-sm mb-6">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal ({cartItems?.length} items)</span>
                  <span className="text-foreground font-medium">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Estimated Tax</span>
                  <span className="text-foreground font-medium">{formatPrice(tax)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span className="text-emerald-500 font-semibold">FREE</span>
                </div>
              </div>

              <hr className="border-border my-6" />
              
              <div className="flex justify-between items-end mb-8">
                <span className="font-semibold">Total</span>
                <span className="font-display font-bold text-3xl text-primary">{formatPrice(total)}</span>
              </div>

              <Button 
                onClick={handleCheckout} 
                size="lg" 
                className="w-full h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-1 transition-all group"
              >
                Proceed to Checkout
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <div className="mt-6 text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4" /> Secure Checkout
              </div>
            </div>
          </div>
          
        </div>
      )}
    </div>
  );
}
