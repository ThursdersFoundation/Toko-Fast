import { Link } from "wouter";
import { ArrowRight, Zap, ShieldCheck, CreditCard } from "lucide-react";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/product/ProductCard";
import { Spinner } from "@/components/ui/spinner";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Home() {
  const { data: products, isLoading } = useProducts();
  
  // Show only first 6 products as featured
  const featuredProducts = products?.slice(0, 6);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        {/* landing page hero minimalist electronic workspace */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1920&q=80" 
            alt="Workspace Hero" 
            className="w-full h-full object-cover opacity-[0.03] dark:opacity-[0.05]"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/50 to-background"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto"
          >
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-6 border border-primary/20">
              ⚡ Lightning Fast Delivery
            </span>
            <h1 className="text-5xl md:text-7xl font-display font-extrabold text-foreground tracking-tight mb-8 leading-tight text-balance">
              Premium tech & books, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                delivered today.
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 text-balance">
              TokoFast brings you the latest electronics and best-selling books with unmatched speed. Upgrade your life without the wait.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button asChild size="lg" className="h-14 px-8 text-lg rounded-full shadow-xl shadow-primary/25 hover:scale-105 transition-all w-full sm:w-auto">
                <Link href="/products">
                  Shop Electronics
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg rounded-full border-2 hover:bg-secondary w-full sm:w-auto">
                <Link href="/products?categoryId=2">
                  Browse Books
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Value Props */}
      <section className="py-16 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Zap, title: "Same-Day Delivery", desc: "Order before 2PM for delivery by evening." },
              { icon: ShieldCheck, title: "100% Original", desc: "Authentic products with manufacturer warranty." },
              { icon: CreditCard, title: "Secure Checkout", desc: "Bank-grade encryption for all payments." }
            ].map((prop, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-4 p-6 bg-card rounded-2xl border border-border shadow-sm"
              >
                <div className="w-14 h-14 bg-primary/10 text-primary rounded-xl flex items-center justify-center shrink-0">
                  <prop.icon className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg">{prop.title}</h3>
                  <p className="text-muted-foreground text-sm">{prop.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">Trending Now</h2>
              <p className="text-muted-foreground text-lg">Our most popular products this week.</p>
            </div>
            <Link href="/products" className="hidden md:flex items-center text-primary font-semibold hover:underline">
              View all products <ArrowRight className="ml-1 w-4 h-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-20">
              <Spinner />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          
          <div className="mt-12 text-center md:hidden">
            <Button asChild variant="outline" size="lg" className="w-full rounded-xl">
              <Link href="/products">View all products</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
