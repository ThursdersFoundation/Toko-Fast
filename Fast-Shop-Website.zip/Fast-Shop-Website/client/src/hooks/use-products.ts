import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { ProductWithCategory } from "@shared/schema";

export function useProducts(categoryId?: string, search?: string) {
  return useQuery({
    queryKey: [api.products.list.path, categoryId, search],
    queryFn: async () => {
      const url = new URL(api.products.list.path, window.location.origin);
      if (categoryId) url.searchParams.append("categoryId", categoryId);
      if (search) url.searchParams.append("search", search);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch products");
      return res.json() as Promise<ProductWithCategory[]>;
    },
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: [api.products.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.products.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch product");
      return res.json() as Promise<ProductWithCategory>;
    },
    enabled: !!id,
  });
}
