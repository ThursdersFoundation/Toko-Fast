import { Loader2 } from "lucide-react";

export function Spinner({ className }: { className?: string }) {
  return (
    <Loader2 className={`w-8 h-8 text-primary animate-spin ${className || ""}`} />
  );
}
