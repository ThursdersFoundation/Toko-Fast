import { Link, useLocation } from "wouter";
import { ShoppingBag, User, LogOut, Package2, Search, Menu } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export function Navbar() {
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { data: cartItems } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cartCount = cartItems?.reduce((sum, item) => sum + item.quantity, 0) || 0;

  const handleCartClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      window.location.href = "/api/login";
    } else {
      setLocation("/cart");
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full glass">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center shadow-lg shadow-primary/25 group-hover:scale-105 transition-transform duration-300">
              <Package2 className="w-6 h-6" />
            </div>
            <span className="font-display font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/70">
              TokoFast
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="font-medium text-muted-foreground hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="/products" className="font-medium text-muted-foreground hover:text-primary transition-colors">
              Shop All
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            
            <button 
              onClick={handleCartClick}
              className="relative p-2 text-foreground hover:text-primary transition-colors rounded-full hover:bg-primary/5"
            >
              <ShoppingBag className="w-6 h-6" />
              <AnimatePresence>
                {cartCount > 0 && (
                  <motion.span 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                    className="absolute top-0 right-0 bg-accent text-accent-foreground text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-sm"
                  >
                    {cartCount > 99 ? '99+' : cartCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>

            <div className="hidden sm:flex items-center gap-4">
              {isAuthenticated && user ? (
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-3 bg-secondary px-4 py-2 rounded-full">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{user.firstName || user.username || 'User'}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => logout()} className="text-muted-foreground hover:text-destructive">
                    <LogOut className="w-5 h-5" />
                  </Button>
                </div>
              ) : (
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="rounded-full px-6 font-semibold shadow-md hover:shadow-lg transition-all"
                >
                  Sign In
                </Button>
              )}
            </div>

            {/* Mobile menu toggle */}
            <button 
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden bg-background border-b border-border"
          >
            <div className="px-4 py-6 flex flex-col gap-4">
              <Link href="/" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium p-2 rounded-lg hover:bg-secondary">
                Home
              </Link>
              <Link href="/products" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium p-2 rounded-lg hover:bg-secondary">
                Shop All
              </Link>
              <hr className="border-border" />
              {isAuthenticated ? (
                <button onClick={() => logout()} className="text-lg font-medium text-left p-2 text-destructive rounded-lg hover:bg-destructive/10">
                  Sign Out
                </button>
              ) : (
                <button onClick={() => window.location.href = '/api/login'} className="text-lg font-medium text-left p-2 text-primary rounded-lg hover:bg-primary/10">
                  Sign In
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
