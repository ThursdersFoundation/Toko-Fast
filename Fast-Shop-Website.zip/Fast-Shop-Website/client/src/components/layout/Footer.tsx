import { Package2 } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-white border-t border-border mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary text-primary-foreground rounded-lg flex items-center justify-center">
                <Package2 className="w-5 h-5" />
              </div>
              <span className="font-display font-bold text-xl">TokoFast</span>
            </div>
            <p className="text-muted-foreground text-balance max-w-sm">
              Your premium destination for electronics, books, and everything you need delivered fast. Quality guaranteed.
            </p>
          </div>
          <div>
            <h4 className="font-display font-semibold mb-4 text-foreground">Shop</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li><a href="/products?categoryId=1" className="hover:text-primary transition-colors">Electronics</a></li>
              <li><a href="/products?categoryId=2" className="hover:text-primary transition-colors">Books</a></li>
              <li><a href="/products" className="hover:text-primary transition-colors">New Arrivals</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-display font-semibold mb-4 text-foreground">Support</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Track Order</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Returns</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-border text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} TokoFast. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
