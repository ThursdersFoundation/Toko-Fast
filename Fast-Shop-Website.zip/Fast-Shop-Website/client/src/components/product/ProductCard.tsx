import { Link } from "wouter";
import { formatPrice } from "@/lib/format";
import type { ProductWithCategory } from "@shared/schema";
import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAddToCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export function ProductCard({ product }: { product: ProductWithCategory }) {
  const { isAuthenticated } = useAuth();
  const { mutate: addToCart, isPending } = useAddToCart();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent Link navigation
    
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }

    addToCart({ productId: product.id, quantity: 1 }, {
      onSuccess: () => {
        toast({
          title: "Added to Cart",
          description: `${product.name} has been added to your shopping cart.`,
          variant: "default",
        });
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message || "Failed to add item to cart.",
          variant: "destructive",
        });
      }
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      className="group flex flex-col bg-card rounded-2xl overflow-hidden border border-border/50 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all"
    >
      <Link href={`/products/${product.id}`} className="block flex-1 relative aspect-[4/3] overflow-hidden bg-secondary/50">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
        />
        {product.stock < 5 && product.stock > 0 && (
          <div className="absolute top-3 left-3 bg-accent text-accent-foreground text-xs font-bold px-3 py-1 rounded-full shadow-sm">
            Only {product.stock} left
          </div>
        )}
        {product.stock === 0 && (
          <div className="absolute top-3 left-3 bg-muted text-muted-foreground text-xs font-bold px-3 py-1 rounded-full shadow-sm">
            Out of stock
          </div>
        )}
      </Link>
      
      <div className="p-5 flex flex-col flex-1">
        <div className="flex justify-between items-start gap-2 mb-2">
          <div>
            {product.category && (
              <span className="text-xs font-medium text-primary mb-1 block uppercase tracking-wider">
                {product.category.name}
              </span>
            )}
            <Link href={`/products/${product.id}`} className="block">
              <h3 className="font-display font-semibold text-foreground text-lg leading-tight group-hover:text-primary transition-colors line-clamp-2">
                {product.name}
              </h3>
            </Link>
          </div>
          <span className="font-bold text-foreground bg-secondary px-3 py-1 rounded-lg shrink-0">
            {formatPrice(product.price)}
          </span>
        </div>
        
        <p className="text-muted-foreground text-sm mb-6 line-clamp-2 flex-1">
          {product.description}
        </p>

        <Button 
          onClick={handleAddToCart}
          disabled={isPending || product.stock === 0}
          className="w-full rounded-xl font-semibold shadow-sm hover:shadow-md transition-all gap-2"
          variant={product.stock === 0 ? "secondary" : "default"}
        >
          {isPending ? (
            <span className="animate-pulse">Adding...</span>
          ) : product.stock === 0 ? (
            "Out of Stock"
          ) : (
            <>
              <ShoppingCart className="w-4 h-4" />
              Add to Cart
            </>
          )}
        </Button>
      </div>
    </motion.div>
  );
}
