import {
  products,
  categories,
  cartItems,
  type Product,
  type Category,
  type CartItem,
  type ProductWithCategory,
  type CartItemWithProduct,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, ilike } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(categoryId?: number, search?: string): Promise<ProductWithCategory[]>;
  getProduct(id: number): Promise<ProductWithCategory | undefined>;

  // Categories
  getCategories(): Promise<Category[]>;

  // Cart
  getCart(userId: string): Promise<CartItemWithProduct[]>;
  addToCart(userId: string, productId: number, quantity: number): Promise<CartItem>;
  updateCartItem(id: number, userId: string, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number, userId: string): Promise<void>;
  clearCart(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(categoryId?: number, search?: string): Promise<ProductWithCategory[]> {
    let query = db.select({
      product: products,
      category: categories,
    })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id));

    const results = await query;
    let filtered = results;

    if (categoryId) {
      filtered = filtered.filter(r => r.product.categoryId === categoryId);
    }
    
    if (search) {
      const lowerSearch = search.toLowerCase();
      filtered = filtered.filter(r => 
        r.product.name.toLowerCase().includes(lowerSearch) || 
        r.product.description.toLowerCase().includes(lowerSearch)
      );
    }

    return filtered.map(row => ({
      ...row.product,
      category: row.category,
    }));
  }

  async getProduct(id: number): Promise<ProductWithCategory | undefined> {
    const results = await db.select({
      product: products,
      category: categories,
    })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(products.id, id));

    if (results.length === 0) return undefined;

    return {
      ...results[0].product,
      category: results[0].category,
    };
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCart(userId: string): Promise<CartItemWithProduct[]> {
    const results = await db.select({
      cartItem: cartItems,
      product: products,
    })
      .from(cartItems)
      .innerJoin(products, eq(cartItems.productId, products.id))
      .where(eq(cartItems.userId, userId));

    return results.map(row => ({
      ...row.cartItem,
      product: row.product,
    }));
  }

  async addToCart(userId: string, productId: number, quantity: number): Promise<CartItem> {
    // Check if it already exists
    const existing = await db.select()
      .from(cartItems)
      .where(and(eq(cartItems.userId, userId), eq(cartItems.productId, productId)));

    if (existing.length > 0) {
      const [updated] = await db.update(cartItems)
        .set({ quantity: existing[0].quantity + quantity })
        .where(eq(cartItems.id, existing[0].id))
        .returning();
      return updated;
    }

    const [newItem] = await db.insert(cartItems)
      .values({ userId, productId, quantity })
      .returning();
    return newItem;
  }

  async updateCartItem(id: number, userId: string, quantity: number): Promise<CartItem | undefined> {
    const [updated] = await db.update(cartItems)
      .set({ quantity })
      .where(and(eq(cartItems.id, id), eq(cartItems.userId, userId)))
      .returning();
    return updated;
  }

  async removeCartItem(id: number, userId: string): Promise<void> {
    await db.delete(cartItems)
      .where(and(eq(cartItems.id, id), eq(cartItems.userId, userId)));
  }

  async clearCart(userId: string): Promise<void> {
    await db.delete(cartItems)
      .where(eq(cartItems.userId, userId));
  }
}

export const storage = new DatabaseStorage();
