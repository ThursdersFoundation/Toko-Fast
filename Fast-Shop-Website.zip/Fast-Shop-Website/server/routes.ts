import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerAuthRoutes, setupAuth, isAuthenticated } from "./replit_integrations/auth";
import { categories, products } from "@shared/schema";
import { db } from "./db";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Set up authentication
  await setupAuth(app);
  registerAuthRoutes(app);

  // Products
  app.get(api.products.list.path, async (req, res) => {
    try {
      // Validate query manually or just parse
      const search = req.query.search as string | undefined;
      const categoryIdStr = req.query.categoryId as string | undefined;
      const categoryId = categoryIdStr ? parseInt(categoryIdStr, 10) : undefined;

      const productsList = await storage.getProducts(categoryId, search);
      res.status(200).json(productsList);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get(api.products.get.path, async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(404).json(api.products.get.responses[404].parse({ message: "Invalid product ID" }));
      }
      
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json(api.products.get.responses[404].parse({ message: "Product not found" }));
      }
      
      res.status(200).json(product);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Categories
  app.get(api.categories.list.path, async (req, res) => {
    try {
      const cats = await storage.getCategories();
      res.status(200).json(cats);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Cart (Protected routes)
  app.get(api.cart.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const cart = await storage.getCart(userId);
      res.status(200).json(cart);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch cart" });
    }
  });

  app.post(api.cart.add.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const input = api.cart.add.input.parse(req.body);
      const item = await storage.addToCart(userId, input.productId, input.quantity || 1);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(api.cart.add.responses[400].parse({ 
          message: err.errors[0].message,
          field: err.errors[0].path.join('.') 
        }));
      }
      res.status(500).json({ message: "Failed to add to cart" });
    }
  });

  app.put(api.cart.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id, 10);
      const input = api.cart.update.input.parse(req.body);
      
      const updated = await storage.updateCartItem(id, userId, input.quantity);
      if (!updated) {
        return res.status(404).json(api.cart.update.responses[404].parse({ message: "Cart item not found" }));
      }
      
      res.status(200).json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(api.cart.update.responses[400].parse({ 
          message: err.errors[0].message,
          field: err.errors[0].path.join('.') 
        }));
      }
      res.status(500).json({ message: "Failed to update cart" });
    }
  });

  app.delete(api.cart.delete.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id, 10);
      
      await storage.removeCartItem(id, userId);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete cart item" });
    }
  });

  // Seed Data (Fire and forget on startup)
  seedDatabase().catch(console.error);

  return httpServer;
}

async function seedDatabase() {
  const existingCats = await storage.getCategories();
  if (existingCats.length === 0) {
    // Insert categories
    const insertedCats = await db.insert(categories).values([
      { name: "Electronics" },
      { name: "Books" },
      { name: "Home & Garden" },
      { name: "Clothing" },
    ]).returning();

    const electronicsId = insertedCats[0].id;
    const booksId = insertedCats[1].id;

    // Insert products
    await db.insert(products).values([
      {
        name: "Wireless Noise-Cancelling Headphones",
        description: "Premium over-ear headphones with active noise cancellation and 30-hour battery life.",
        price: 29999, // $299.99
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop",
        categoryId: electronicsId,
        stock: 50
      },
      {
        name: "Smartphone Pro Max",
        description: "Latest generation smartphone with pro-grade camera system and all-day battery.",
        price: 109900, // $1099.00
        imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1000&auto=format&fit=crop",
        categoryId: electronicsId,
        stock: 25
      },
      {
        name: "The Pragmatic Programmer",
        description: "A classic software engineering book about becoming a better developer.",
        price: 3550, // $35.50
        imageUrl: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?q=80&w=1000&auto=format&fit=crop",
        categoryId: booksId,
        stock: 100
      },
      {
        name: "Atomic Habits",
        description: "The practical guide to improving your software craft.",
        price: 3200, // $32.00
        imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=1000&auto=format&fit=crop",
        categoryId: booksId,
        stock: 80
      },
      {
        name: "4K Monitor 27-inch",
        description: "Ultra HD computer monitor with true-to-life colors and sleek design.",
        price: 34999, // $349.99
        imageUrl: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?q=80&w=1000&auto=format&fit=crop",
        categoryId: electronicsId,
        stock: 15
      }
    ]);
    
    console.log("Database seeded successfully.");
  }
}
